package com.edutech.edutech.proveedor.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.edutech.edutech.proveedor.model.Proveedor;

public interface ProveedorRepository extends JpaRepository<Proveedor, String> {

}
