package com.edutech.edutech.curso.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.edutech.edutech.curso.model.Curso;

public interface CursoRepository extends JpaRepository<Curso, String>{

}
