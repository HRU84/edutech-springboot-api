package com.edutech.edutech.contenido.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.edutech.edutech.contenido.model.Contenido;

public interface ContenidoRepository extends JpaRepository<Contenido, Long>{

}
