package com.edutech.edutech.evaluacion.dto;

public class EvaluacionDTO {
    private String nombre;
    private String cursoSigla;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCursoSigla() {
        return cursoSigla;
    }

    public void setCursoSigla(String cursoSigla) {
        this.cursoSigla = cursoSigla;
    }
}