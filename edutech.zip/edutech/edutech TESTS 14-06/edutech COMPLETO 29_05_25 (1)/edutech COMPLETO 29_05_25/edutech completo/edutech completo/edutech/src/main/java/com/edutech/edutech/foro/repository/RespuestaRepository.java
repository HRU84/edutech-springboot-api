package com.edutech.edutech.foro.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.edutech.edutech.foro.model.Respuesta;

public interface RespuestaRepository extends JpaRepository<Respuesta, Integer> {
    
    

}
