package com.edutech.edutech.resultado.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.edutech.edutech.resultado.model.Resultado_Evaluacion;

public interface ResultadoEvaluacionRepository extends JpaRepository<Resultado_Evaluacion, Long> {

}
