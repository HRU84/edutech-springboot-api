package com.edutech.edutech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EdutechApplicationTests {

	@Test
	void contextLoads() {
	}

}
