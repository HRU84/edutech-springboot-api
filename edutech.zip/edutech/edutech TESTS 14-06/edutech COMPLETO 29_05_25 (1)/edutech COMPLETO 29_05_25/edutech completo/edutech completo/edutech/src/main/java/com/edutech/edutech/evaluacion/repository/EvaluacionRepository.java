package com.edutech.edutech.evaluacion.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.edutech.edutech.evaluacion.model.Evaluacion;

public interface EvaluacionRepository extends JpaRepository<Evaluacion, Long>{

}
